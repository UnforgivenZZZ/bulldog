07/72/2017 17:17
adding new item function has been update
Creating a new form
Making a new categries before inserting new product
There are 4 types error I have fixed, such as 
id, seller, and price, they need to be cast to int / double
before inserting into database