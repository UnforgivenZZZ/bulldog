package com.masasdani.paypal.config;

public enum PaypalPaymentIntent {

    sale, authorize, order

}